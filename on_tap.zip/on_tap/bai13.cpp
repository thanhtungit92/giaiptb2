#include <stdio.h>
#include <iostream>
#include <math.h>

using namespace std;
main()
{
    int tong;
    cout<<"So co tong bang lap phuong cac chu so: ";
    for (int i = 100; i < 1000; i++) {
        tong = pow(i % 10,3) + pow((i/10)%10, 3) + pow(i/100, 3);
        if (tong == i) {
            cout<<i<<" ";
        }
    }
    
}
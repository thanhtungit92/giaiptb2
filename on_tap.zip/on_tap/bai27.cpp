#include <stdio.h>
#include <iostream>
#include<string.h>

using namespace std;
int demtu(char a[]) {
    int tu = 1;
    for (int i = 0; i < strlen(a); i++) {
        if (a[i] == ' ' && i != strlen(a) - 1) {
            tu++;
        }
    }
    return tu;
}
main()
{
    char a[100];
    int hoa = 0;
    int thuong = 0;
    int dacbiet = 0;
    cout<<"Nhap chuoi ki tu: ";
    cin>>a;
    cout<<"Chuoi co " << demtu(a) <<" tu";
}
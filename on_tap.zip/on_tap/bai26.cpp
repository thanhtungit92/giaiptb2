#include <stdio.h>
#include <iostream>
#include<string.h>

using namespace std;
bool doiXung(int n, char a[]) {
    for (int i = 0; i < n/2; i++) {
        if (a[i] != a[n - 1 - i]) {
            return false;
        }
    }
    return true;
}
main()
{
    char a[100];
    int hoa = 0;
    int thuong = 0;
    int dacbiet = 0;
    cout<<"Nhap chuoi ki tu: ";
    cin>>a;
    if (doiXung(strlen(a), a)) {
        cout<<"Chuoi doi xung";
    } else {
        cout<<"Chuoi khong doi xung";
    }
}
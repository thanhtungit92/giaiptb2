#include <stdio.h>
#include <iostream>

using namespace std;
void nhapMang(int n, int a[]) {
    for (int i = 0; i < n; i++) {
        cout<<"Nhap phan tu thu "<<i<<": \n";
        cin>>a[i];
    }
}
int TongSoChanMang(int n, int a[]) {
    int tong = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] % 2== 0) {
            tong += a[i];
        }
    }
    return tong;
}
main()
{
    int n;
    cout<<"Nhap so phan tu: \n";
    cin>>n;
    nhapMang(n, a);
    cout<<"Tong cac so chan trong mang: " <<TongSoChanMang(n, a);
}
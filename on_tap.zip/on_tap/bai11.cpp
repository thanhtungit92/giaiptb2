#include <stdio.h>
#include <iostream>

using namespace std;
int fibonacci(int n) {
    if (n == 0) {
        return 0;
    }
    if (n == 1) {
        return 1;
    }
    return fibonacci(n - 1) + fibonacci(n - 2);
}
main()
{
    int n;
    cout<<"Nhap n: \n";
    cin>>n;
    cout<<"Số fibonacci thứ n: " <<fibonacci(n);
}
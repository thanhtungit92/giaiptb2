#include <stdio.h>
#include <iostream>

using namespace std;
void nhapMang(int n, int a[]) {
    for (int i = 0; i < n; i++) {
        cout<<"Nhap phan tu thu "<<i<<": \n";
        cin>>a[i];
    }
}
bool soNguyenTo(int soKt) {
    if (soKt == 2) {
        return true;
    }
    for (int i = 2; i <= soKt/2; i++) {
        if (soKt % i == 0) {
            return false;
        }
    }
    return true;
}
float tbNguyenTo(int n, int a[]) {
    int tong;
    int dem;
    for (int i = 0; i < n; i++) {
        if (soNguyenTo(a[i])) {
            dem++;
            tong += a[i];
        }
    }
    return (float)tong/(float)dem;
}
main()
{
    int n;
    cout<<"Nhap so phan tu: \n";
    cin>>n;
    nhapMang(n, a);
    float tb = tbNguyenTo(n, a);
    cout<<"Trung binh cac so nguyen to trong mang: " <<tb;
}
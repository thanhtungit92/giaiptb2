#include <stdio.h>
#include <iostream>

using namespace std;
void nhapMang(int n, int a[]) {
    for (int i = 0; i < n; i++) {
        cout<<"Nhap phan tu thu "<<i<<": \n";
        cin>>a[i];
    }
}
void TongLonNhat(int n, int a[]) {
    int max1 = INT8_MIN;
    int max2 = INT8_MIN;
    if (n <= 1) {
        cout<<"Mang khong du phan tu";
    } else {
        max1 = a[0];
        for (int i = 1; i < n; i++) {
            if (max1 < a[i]) {
                max2 = max1;
                max1 = a[i];
            } else {
                if (max2 < a[i]) {
                    max2 = a[i];
                }
            }
        }
        cout<<"Hai phan tu co tong lon nhat: "<<max1<<" "<<max2;
    }
}
main()
{
    int n;
    cout<<"Nhap so phan tu: \n";
    cin>>n;
    nhapMang(n, a);
    TongLonNhat(n, a);   
}
#include <stdio.h>
#include <iostream>
#include<string.h>

using namespace std;

main()
{
    char a[100];
    int hoa = 0;
    int thuong = 0;
    int dacbiet = 0;
    cout<<"Nhap chuoi ki tu: ";
    cin>>a;
    for(int i = 0; i < strlen(a); i++) {
        if (a[i] >= 'a' && a[i] <= 'z') {
            thuong++;
        } else if (a[i] >= 'A' && a[i] <= 'Z') {
            hoa++;
        } else {
            dacbiet++;
        }
    }
    cout<<"So ki tu hoa: "<<hoa<<"\n";
    cout<<"So ki tu thuong: "<<thuong<<"\n";
    cout<<"So ki tu dac biet: "<<dacbiet<<"\n";
}
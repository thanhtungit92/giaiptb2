#include <stdio.h>
#include <iostream>

using namespace std;
void nhapMang(int n, int a[]) {
    for (int i = 0; i < n; i++) {
        cout<<"Nhap phan tu thu "<<i<<": \n";
        cin>>a[i];
    }
}
bool soNguyenTo(int soKt) {
    if (soKt == 2) {
        return true;
    }
    for (int i = 2; i <= soKt/2; i++) {
        if (soKt % i == 0) {
            return false;
        }
    }
    return true;
}
int soNgToLonNhat(int n, int a[]) {
    int max = INT8_MIN;
    for (int i = 0; i < n; i++) {
        if (soNguyenTo(a[i])) {
            if (max < a[i]) {
                max = a[i];
            }
        }
    }
    return max;
}
main()
{
    int n;
    cout<<"Nhap so phan tu: ";
    cin>>n;
    nhapMang(n, a);
    int soNtoLonNhat = soNgToLonNhat(n, a);
    if (soNtoLonNhat == INT8_MIN) {
        cout<<"Mang khong co so nguyen to";
    } else {
        cout<<"So nguyen to lon nhat: "<<soNtoLonNhat;
    }
    
}
#include <stdio.h>
#include <iostream>

using namespace std;
void nhapMang(int n, int a[]) {
    for (int i = 0; i < n; i++) {
        cout<<"Nhap phan tu thu "<<i<<": \n";
        cin>>a[i];
    }
}
void xuatMang(int n, int a[]) {
    cout<<"Mang a: ";
    for (int i = 0; i < n; i++) {
        cout<<a[i]<<" ";
    }
}
main()
{
    int n;
    cout<<"Nhap so phan tu: ";
    cin>>n;
    nhapMang(n, a);
    xuatMang(n, a);
}
#include <stdio.h>
#include <iostream>

using namespace std;
void nhapMang(int n, int a[]) {
    for (int i = 0; i < n; i++) {
        cout<<"Nhap phan tu thu "<<i<<": \n";
        cin>>a[i];
    }
}
void xuatMang(int n, int a[]) {
    cout<<"Mang a: ";
    for (int i = 0; i < n; i++) {
        cout<<a[i]<<" ";
    }
}
void chenVitri(int &n, int a[], int vt, int gt) {
    
    if (vt >=0 && vt < n) {
        n++;
        for (int i = n-1; i >= vt; i--) {
            if (i != vt) {
                a[i] = a[i - 1];
            } else {
                a[i] = gt;    
            }
        }
    }
}
main()
{
    int n;
    cout<<"Nhap so phan tu: ";
    cin>>n;
    nhapMang(n, a);
    chenVitri(n, a, 2, 4);
    xuatMang(n, a);
}
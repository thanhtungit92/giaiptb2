#include <stdio.h>
#include <iostream>

using namespace std;
void nhapMang(int n, int a[]) {
    for (int i = 0; i < n; i++) {
        cout<<"Nhap phan tu thu "<<i<<": \n";
        cin>>a[i];
    }
}
void xuatMang(int n, int a[]) {
    cout<<"Mang a: ";
    for (int i = 0; i < n; i++) {
        cout<<a[i]<<" ";
    }
}
void chuyenGiaTri(int n, int a[], int vt) {
    int temp = a[vt];
    for (int i = vt; i >= 0; i--) {
        a[i] = a[i - 1];
    }
    a[0] = temp;
}
bool soHoanThien(int soKt) {
    int tong = soKt;
    for (int i = 1; i <= soKt/2; i++) {
        if (soKt % i == 0) {
            tong += i;
        }
    }
    if (tong == soKt *2) {
        return true;
    } else {
        return false;
    }
}

void chuyenSoHoanThien(int n, int a[]) {
    for (int i = 0; i < n; i++) {
        if (soHoanThien(a[i])) {
            chuyenGiaTri(n, a, i);
        }
    }
}

main()
{
    int n;
    cout<<"Nhap so phan tu: \n";
    cin>>n;
	nhapMang(n, a);
    chuyenSoHoanThien(n, a);
    cout<<"Mang sau khi chuyen so hoan thien len dau\n";
    xuatMang(n, a);
}
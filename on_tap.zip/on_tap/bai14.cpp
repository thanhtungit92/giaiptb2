#include <stdio.h>
#include <iostream>

using namespace std;
void nhapMang(int n, int a[]) {
    for (int i = 0; i < n; i++) {
        cout<<"Nhap phan tu thu "<<i<<": ";
        cin>>a[i];
    }
}
main()
{
    int n;
    cout<<"Nhap so phan tu: ";
    cin>>n;
    int a[n];
    nhapMang(n, a);
}
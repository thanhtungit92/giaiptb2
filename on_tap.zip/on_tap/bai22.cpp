#include <stdio.h>
#include <iostream>

using namespace std;
void nhapMang(int n, int a[]) {
    for (int i = 0; i < n; i++) {
        cout<<"Nhap phan tu thu "<<i<<": \n";
        cin>>a[i];
    }
}
void xuatMang(int n, int a[]) {
    cout<<"Mang a: ";
    for (int i = 0; i < n; i++) {
        cout<<a[i]<<" ";
    }
}
void xoaPt(int &n, int a[], int vt) {
    for (int i = vt; i < n -1; i++) {
        a[i] = a[i + 1];
    }
    n--;
}

void xoaAm(int &n, int a[]) {
    for (int i = 0; i < n; i++) {
        if (a[i] < 0) {
           xoaPt(n, a, i);
           i--;
        }
    }
}

main()
{
    int n;
    cout<<"Nhap so phan tu: \n";
    cin>>n;
    nhapMang(n, a);
    xoaAm(n, a);
    cout<<"Mang sau khi xoa gia tri am\n";
    xuatMang(n, a);
}
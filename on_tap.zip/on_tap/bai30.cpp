#include <stdio.h>
#include <iostream>
#include<string.h>

using namespace std;
main()
{
    char a[100];
    int n;
    cout<<"Nhap chuoi ki tu: ";
    cin>>a;
    cout<<"Nhap gia tri n:";
    cin>>n;
    char b[n];
    for (int i = 0; i < n; i++) {
        b[i] = a[strlen(a) - n + i];
    }
    cout<<b;
}